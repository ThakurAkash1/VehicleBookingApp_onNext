const { Sequelize } = require('sequelize');


const sequelize = new Sequelize('VehicleBooking', 'root', 'Akash@123', {
  host: 'localhost',
  dialect: 'mysql',
  port: 3306,
});

// Test database connection
sequelize
  .authenticate()
  .then(() => {
    console.log('Database connection established successfully.');


    return sequelize.sync({ force: false });
  })
  .then(() => {
    console.log('Database synchronized successfully.');
  })
  .catch((error) => {
    console.error('Error connecting to or synchronizing the database:', error);
  });

module.exports = sequelize;
