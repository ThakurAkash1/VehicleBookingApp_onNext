const { DataTypes } = require('sequelize');
const sequelize = require('../utils/db');
const VehicleType = require('./VehicleType');

const Vehicle = sequelize.define('Vehicle', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING, allowNull: false },
  typeId: {
    type: DataTypes.INTEGER,
    references: { model: VehicleType, key: 'id' },
    allowNull: false,
  },
}, {
  timestamps: false,
});

Vehicle.belongsTo(VehicleType, { foreignKey: 'typeId' });

module.exports = Vehicle;
