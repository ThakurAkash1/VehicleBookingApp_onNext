const { DataTypes } = require('sequelize');
const sequelize = require('../utils/db');

const VehicleType = sequelize.define(
  'VehicleType',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);

module.exports = VehicleType;
