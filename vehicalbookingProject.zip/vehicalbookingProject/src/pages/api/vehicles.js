import { DataTypes } from 'sequelize';
import sequelize from '../utils/sequelize';

const VehicleType = sequelize.define('VehicleType', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

export default VehicleType;

