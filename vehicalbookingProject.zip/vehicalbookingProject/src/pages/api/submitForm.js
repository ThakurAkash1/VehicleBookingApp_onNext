import Booking from '@/models/Booking';
import Vehicle from '@/models/Vehicle';
const VehicleType = require('../../models/VehicleType');
import { Op } from 'sequelize';

const handler = async (req, res) => {
  if (req.method === 'POST') {
    console.log('Raw request body:', req.body);
    try {
      const { firstName, lastName, vehicleType, vehicleModel, registrationNumber, startDate, endDate } = req.body;

      console.log('Received startDate:', startDate);
      console.log('Received endDate:', endDate);

      // Validate required fields
      if (!startDate || !endDate) {
        return res.status(400).json({ error: 'Start date and end date are required' });
      }

      // Find vehicle type
      const vehicleTypeRecord = await VehicleType.findOne({ where: { type: vehicleType } });
      if (!vehicleTypeRecord) {
        return res.status(404).json({ error: 'Vehicle type not found' });
      }

      // Find or create the vehicle
      let vehicle = await Vehicle.findOne({
        where: { name: vehicleModel, typeId: vehicleTypeRecord.id },
      });
      if (!vehicle) {
        vehicle = await Vehicle.create({
          name: vehicleModel,
          typeId: vehicleTypeRecord.id,
          registrationNumber,
        });
      }

      // Check for overlapping bookings (Add this check)
      const existingBooking = await Booking.findOne({
        where: {
          vehicleId: vehicle.id,
          startDate: { [Op.lt]: endDate },
          endDate: { [Op.gt]: startDate },
        },
      });

      if (existingBooking) {
        return res.status(400).json({ error: 'This vehicle is already booked for the selected dates' });
      }

      // Create booking
      const booking = await Booking.create({
        vehicleId: vehicle.id,
        firstName,
        lastName,
        name: `${firstName} ${lastName}`,
        startDate,
        endDate,
      });

      res.status(201).json({ message: 'Booking created successfully', booking });
    } catch (error) {
      console.error('Error submitting booking:', error);
      if (error.name === 'SequelizeValidationError') {
        return res.status(400).json({ error: 'Validation error', details: error.errors });
      }
      res.status(500).json({ error: 'An error occurred' });
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' });
  }
};
export const config = {
  api: {
    bodyParser: true,
  },
};

export default handler;
