const Booking = require('../../../models/Booking');

export default async (req, res) => {
    const { vehicleId, name, startDate, endDate } = req.body;

    const existingBooking = await Booking.findOne({
        where: { vehicleId, startDate, endDate },
    });

    if (existingBooking) {
        return res.status(400).json({ message: 'Vehicle already booked for this period' });
    }

    const newBooking = await Booking.create({ vehicleId, name, startDate, endDate });
    res.status(201).json(newBooking);
};
