import { useState } from 'react';
import FormStep4 from './components/FormStep4';
import 'bootstrap/dist/css/bootstrap.min.css';

const Form = () => {
  const today = new Date().toISOString().split('T')[0];
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    vehicleType: '',
    vehicleModel: '',
    registrationNumber: '',
    startDate: today,
    endDate: today,
  });

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    console.log('Form submitted:', formData);
    setFormData({
      firstName: '',
      lastName: '',
      vehicleType: '',
      vehicleModel: '',
      registrationNumber: '',
      startDate: today,
      endDate: today,
    });
  };

  return (
    <div>
      <h1>Booking Form</h1>
      <label>
        First Name:
        <input
          type="text"
          name="firstName"
          value={formData.firstName}
          onChange={handleInputChange}
        />
      </label>
      <label>
        Last Name:
        <input
          type="text"
          name="lastName"
          value={formData.lastName}
          onChange={handleInputChange}
        />
      </label>
      <label>
        Vehicle Type:
        <input
          type="text"
          name="vehicleType"
          value={formData.vehicleType}
          onChange={handleInputChange}
        />
      </label>
      <label>
        Vehicle Model:
        <input
          type="text"
          name="vehicleModel"
          value={formData.vehicleModel}
          onChange={handleInputChange}
        />
      </label>
      <label>
        Registration Number:
        <input
          type="text"
          name="registrationNumber"
          value={formData.registrationNumber}
          onChange={handleInputChange}
        />
      </label>
      <label>
        Start Date:
        <input
          type="date"
          name="startDate"
          value={formData.startDate}
          onChange={handleInputChange}
        />
      </label>
      <label>
        End Date:
        <input
          type="date"
          name="endDate"
          value={formData.endDate}
          onChange={handleInputChange}
        />
      </label>
      <FormStep4 formData={formData} onSubmit={handleSubmit} />
    </div>
  );
};

export default Form;
