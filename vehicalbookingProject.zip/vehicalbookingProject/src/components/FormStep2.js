import { useState, useEffect } from 'react';

const FormStep2 = ({ onNext }) => {
  const [vehicleTypes, setVehicleTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchVehicleTypes = async () => {
      try {
        const response = await fetch('/api/vehicleTypes');
        if (!response.ok) {
          throw new Error('Failed to fetch vehicle types');
        }
        const data = await response.json();
        setVehicleTypes(data);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching vehicle types:', err);
        setError('Failed to load vehicle types');
        setLoading(false);
      }
    };

    fetchVehicleTypes();
  }, []);

  if (loading) {
    return <div className="text-center mt-5">Loading...</div>;
  }

  if (error) {
    return <div className="alert alert-danger mt-5">{error}</div>;
  }

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Choose Vehicle Type</h2>

      {vehicleTypes.length > 0 ? (
        <div className="form-group">
          {vehicleTypes.map((type) => (
            <div key={type.id} className="form-check">
              <input
                type="radio"
                className="form-check-input"
                id={`vehicleType-${type.id}`}
                name="vehicleType"
                value={type.type}
                onChange={(e) => onNext({ vehicleType: e.target.value })}
              />
              <label className="form-check-label" htmlFor={`vehicleType-${type.id}`}>
                {type.type}
              </label>
            </div>
          ))}
        </div>
      ) : (
        <div>No vehicle types available</div>
      )}
      <div className="text-center mt-4">
        <button className="btn btn-primary" onClick={() => onNext({})}>
          Next
        </button>
      </div>
    </div>
  );
};

export default FormStep2;
