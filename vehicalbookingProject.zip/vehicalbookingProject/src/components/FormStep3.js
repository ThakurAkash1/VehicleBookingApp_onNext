import { useState } from 'react';

const FormStep3 = ({ onNext }) => {
  const [vehicleModel, setVehicleModel] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');

  const handleNext = () => {
    if (!vehicleModel || !registrationNumber) {
      alert('Please fill in all fields!');
      return;
    }
    onNext({ vehicleModel, registrationNumber });
  };

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
      <div className="row">
        <div className="col-12 col-md-8 col-lg-10 mx-auto">
          <h2 className="text-center mb-4">Enter Vehicle Details</h2>

          {/* Vehicle Model Input */}
          <div className="mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Vehicle Model"
              value={vehicleModel}
              onChange={(e) => setVehicleModel(e.target.value)}
            />
          </div>

          {/* Registration Number Input */}
          <div className="mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Registration Number"
              value={registrationNumber}
              onChange={(e) => setRegistrationNumber(e.target.value)}
            />
          </div>

          <div className="text-center">
            <button className="btn btn-primary" onClick={handleNext}>
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormStep3;
