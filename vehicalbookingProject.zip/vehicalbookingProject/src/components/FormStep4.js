import { useState, useEffect } from 'react';

const FormStep4 = ({ formData, onSubmit }) => {
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    formData.startDate = formData.startDate || new Date().toISOString().split('T')[0];
    formData.endDate = formData.endDate || new Date().toISOString().split('T')[0];
  }, [formData]);

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      console.log('Form Data before submission:', formData);
      const response = await fetch('/api/submitForm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (!response.ok) {
        throw new Error('Submission failed');
      }
      alert('Form submitted successfully!');
      onSubmit(); // Reset or navigate away
    } catch (err) {
      console.error('Error submitting form:', err);
      alert('Failed to submit the form. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
      <div className="row w-100">
        <div className="col-12 col-md-8 col-lg-6 mx-auto">
          <h2 className="text-center mb-4">Confirm and Submit</h2>

          <div className="mb-4">
            <h3 className="mb-3">Review your details:</h3>
            <ul className="list-group">
              <li className="list-group-item"><strong>First Name:</strong> {formData.firstName}</li>
              <li className="list-group-item"><strong>Last Name:</strong> {formData.lastName}</li>
              <li className="list-group-item"><strong>Vehicle Type:</strong> {formData.vehicleType}</li>
              <li className="list-group-item"><strong>Vehicle Model:</strong> {formData.vehicleModel}</li>
              <li className="list-group-item"><strong>Registration Number:</strong> {formData.registrationNumber}</li>
              <li className="list-group-item"><strong>Start Date:</strong> {formData.startDate}</li>
              <li className="list-group-item"><strong>End Date:</strong> {formData.endDate}</li>
            </ul>
          </div>

          <div className="d-flex justify-content-center">
            <button
              className="btn btn-primary"
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? 'Submitting...' : 'Submit'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormStep4;
