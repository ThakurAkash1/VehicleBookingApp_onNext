'use client';
import { useState } from 'react';
import FormStep1 from '@/components/FormStep';
import FormStep2 from '@/components/FormStep2';
import FormStep3 from '@/components/FormStep3';
import FormStep4 from '@/components/FormStep4';

const App = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});

  const handleNext = (data) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setStep((prev) => prev + 1);
  };

  const handleSubmit = () => {
    setFormData({});
    setStep(1); 
  };

  return (
    <div>
      {step === 1 && <FormStep1 onNext={handleNext} />}
      {step === 2 && <FormStep2 onNext={handleNext} />}
      {step === 3 && <FormStep3 onNext={handleNext} />}
      {step === 4 && <FormStep4 formData={formData} onSubmit={handleSubmit} />}
    </div>
  );
};

export default App;
