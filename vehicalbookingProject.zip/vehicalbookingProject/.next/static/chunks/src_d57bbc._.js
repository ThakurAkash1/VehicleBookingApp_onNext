(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_d57bbc._.js", {

"[project]/src/components/FormStep.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// import { useState } from 'react';
// const FormStep1 = ({ onNext }) => {
//   const [firstName, setFirstName] = useState('');
//   const [lastName, setLastName] = useState('');
//   const handleNext = () => {
//     if (firstName && lastName) {
//       onNext({ firstName, lastName });
//     } else {
//       alert('Please fill in your name');
//     }
//   };
//   return (
//     <div>
//       <h2>What is your name?</h2>
//       <input
//         type="text"
//         placeholder="First Name"
//         value={firstName}
//         onChange={(e) => setFirstName(e.target.value)}
//       />
//       <input
//         type="text"
//         placeholder="Last Name"
//         value={lastName}
//         onChange={(e) => setLastName(e.target.value)}
//       />
//       <button onClick={handleNext}>Next</button>
//     </div>
//   );
// };
// export default FormStep1;
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
const FormStep1 = ({ onNext })=>{
    _s();
    const [firstName, setFirstName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [lastName, setLastName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const handleNext = ()=>{
        if (firstName && lastName) {
            onNext({
                firstName,
                lastName
            });
        } else {
            alert('Please fill in your name');
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "d-flex justify-content-center align-items-center min-vh-100",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "card p-4",
            style: {
                width: '100%',
                maxWidth: '400px'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-center mb-4",
                    children: "What is your name?"
                }, void 0, false, {
                    fileName: "[project]/src/components/FormStep.js",
                    lineNumber: 55,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        className: "form-control",
                        placeholder: "First Name",
                        value: firstName,
                        onChange: (e)=>setFirstName(e.target.value)
                    }, void 0, false, {
                        fileName: "[project]/src/components/FormStep.js",
                        lineNumber: 57,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/FormStep.js",
                    lineNumber: 56,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        className: "form-control",
                        placeholder: "Last Name",
                        value: lastName,
                        onChange: (e)=>setLastName(e.target.value)
                    }, void 0, false, {
                        fileName: "[project]/src/components/FormStep.js",
                        lineNumber: 66,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/FormStep.js",
                    lineNumber: 65,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "d-grid",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "btn btn-primary",
                        onClick: handleNext,
                        children: "Next"
                    }, void 0, false, {
                        fileName: "[project]/src/components/FormStep.js",
                        lineNumber: 75,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/FormStep.js",
                    lineNumber: 74,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/FormStep.js",
            lineNumber: 54,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/FormStep.js",
        lineNumber: 53,
        columnNumber: 5
    }, this);
};
_s(FormStep1, "nKDhQq9MYs1tO8AVH68rBUfX7/U=");
_c = FormStep1;
const __TURBOPACK__default__export__ = FormStep1;
var _c;
__turbopack_refresh__.register(_c, "FormStep1");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/FormStep2.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// import { useState, useEffect } from 'react';
// const FormStep2 = ({ onNext }) => {
//   const [vehicleTypes, setVehicleTypes] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   useEffect(() => {
//     const fetchVehicleTypes = async () => {
//       try {
//         const response = await fetch('/api/vehicleTypes');
//         if (!response.ok) {
//           throw new Error('Failed to fetch vehicle types');
//         }
//         const data = await response.json();
//         setVehicleTypes(data);
//         setLoading(false);
//       } catch (err) {
//         console.error('Error fetching vehicle types:', err);
//         setError('Failed to load vehicle types');
//         setLoading(false);
//       }
//     };
//     fetchVehicleTypes();
//   }, []);
//   if (loading) {
//     return <div>Loading...</div>;
//   }
//   if (error) {
//     return <div>{error}</div>;
//   }
//   return (
//     <div>
//       <h2>Step 2: Choose Vehicle Type</h2>
//       {/* {vehicleTypes.length > 0 ? (
//         <div>
//           {vehicleTypes.map((type) => (
//             <div key={type.id}>
//               <input
//                 type="radio"
//                 id={`vehicleType-${type.id}`}
//                 name="vehicleType"
//                 value={type.name}
//                 onChange={(e) => onNext({ vehicleType: e.target.value })}
//               />
//               <label htmlFor={`vehicleType-${type.id}`}>{type.name}</label>
//             </div>
//           ))}
//         </div>
//       ) : (
//         <div>No vehicle types available</div>
//       )} */}
//       {vehicleTypes.map((type) => (
//         <div key={type.id}>
//           <input
//             type="radio"
//             id={`vehicleType-${type.id}`}
//             name="vehicleType"
//             value={type.type} // Ensure 'type' is correct based on the API response
//             onChange={(e) => onNext({ vehicleType: e.target.value })}
//           />
//           <label htmlFor={`vehicleType-${type.id}`}>{type.type}</label>
//         </div>
//       ))}
//       <button onClick={() => onNext({})}>Next</button>
//     </div>
//   );
// };
// export default FormStep2;
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [app-client] (ecmascript)"); // Import the router to handle page redirection
;
var _s = __turbopack_refresh__.signature();
;
;
const FormStep2 = ({ onNext })=>{
    _s();
    const [vehicleTypes, setVehicleTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])(); // Use router for page navigation
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FormStep2.useEffect": ()=>{
            const fetchVehicleTypes = {
                "FormStep2.useEffect.fetchVehicleTypes": async ()=>{
                    try {
                        const response = await fetch('/api/vehicleTypes');
                        if (!response.ok) {
                            throw new Error('Failed to fetch vehicle types');
                        }
                        const data = await response.json();
                        setVehicleTypes(data);
                        setLoading(false);
                    } catch (err) {
                        console.error('Error fetching vehicle types:', err);
                        setError('Failed to load vehicle types');
                        setLoading(false);
                    }
                }
            }["FormStep2.useEffect.fetchVehicleTypes"];
            fetchVehicleTypes();
        }
    }["FormStep2.useEffect"], []);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mt-5",
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/src/components/FormStep2.js",
            lineNumber: 110,
            columnNumber: 12
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "alert alert-danger mt-5",
            children: error
        }, void 0, false, {
            fileName: "[project]/src/components/FormStep2.js",
            lineNumber: 114,
            columnNumber: 12
        }, this);
    }
    // Handle radio button change to redirect to the next page
    const handleRadioChange = (value)=>{
        onNext({
            vehicleType: value
        }); // Send data to parent on change
        router.push('/nextPage'); // Redirect to the next page (you can replace '/nextPage' with your target path)
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mt-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-center mb-4",
                children: "Step 2: Choose Vehicle Type"
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep2.js",
                lineNumber: 125,
                columnNumber: 7
            }, this),
            vehicleTypes.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "form-group",
                children: vehicleTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "form-check d-flex align-items-center justify-content-center mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "radio",
                                className: "form-check-input",
                                id: `vehicleType-${type.id}`,
                                name: "vehicleType",
                                value: type.type,
                                onChange: ()=>handleRadioChange(type.type)
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep2.js",
                                lineNumber: 132,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "form-check-label",
                                htmlFor: `vehicleType-${type.id}`,
                                style: {
                                    marginLeft: '10px'
                                },
                                children: type.type
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep2.js",
                                lineNumber: 140,
                                columnNumber: 15
                            }, this)
                        ]
                    }, type.id, true, {
                        fileName: "[project]/src/components/FormStep2.js",
                        lineNumber: 131,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep2.js",
                lineNumber: 129,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "No vehicle types available"
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep2.js",
                lineNumber: 147,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/FormStep2.js",
        lineNumber: 124,
        columnNumber: 5
    }, this);
};
_s(FormStep2, "Mw1a/R1YtAI/52XrqD/m61ceklQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = FormStep2;
const __TURBOPACK__default__export__ = FormStep2;
var _c;
__turbopack_refresh__.register(_c, "FormStep2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/FormStep3.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
const FormStep3 = ({ onNext })=>{
    _s();
    const [vehicleModel, setVehicleModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [registrationNumber, setRegistrationNumber] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const handleNext = ()=>{
        if (!vehicleModel || !registrationNumber) {
            alert('Please fill in all fields!');
            return;
        }
        onNext({
            vehicleModel,
            registrationNumber
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                children: "Step 3: Enter Vehicle Details"
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep3.js",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "text",
                placeholder: "Vehicle Model",
                value: vehicleModel,
                onChange: (e)=>setVehicleModel(e.target.value)
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep3.js",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "text",
                placeholder: "Registration Number",
                value: registrationNumber,
                onChange: (e)=>setRegistrationNumber(e.target.value)
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep3.js",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleNext,
                children: "Next"
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep3.js",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/FormStep3.js",
        lineNumber: 16,
        columnNumber: 5
    }, this);
};
_s(FormStep3, "zaU20mbGJX5E2F5z+xGhNfAbohU=");
_c = FormStep3;
const __TURBOPACK__default__export__ = FormStep3;
var _c;
__turbopack_refresh__.register(_c, "FormStep3");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/FormStep4.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// import { useState } from 'react';
//   const FormStep4 = ({ formData, onSubmit }) => {
//   const [submitting, setSubmitting] = useState(false);
//   const handleSubmit = async () => {
//     setSubmitting(true);
//     try {
//       console.log('Form Data before submission:', formData); 
//       const response = await fetch('/api/submitForm', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(formData),
//       });
//       if (!response.ok) {
//         throw new Error('Submission failed');
//       }
//       alert('Form submitted successfully!');
//       onSubmit(); // Reset or navigate away
//     } catch (err) {
//       console.error('Error submitting form:', err);
//       alert('Failed to submit the form. Please try again.');
//     } finally {
//       setSubmitting(false);
//     }
//   };
//   return (
//     <div>
//       <h2>Step 4: Confirm and Submit</h2>
//       <div>
//         <h3>Review your details:</h3>
//         <p><strong>First Name:</strong> {formData.firstName}</p>
//         <p><strong>Last Name:</strong> {formData.lastName}</p>
//         <p><strong>Vehicle Type:</strong> {formData.vehicleType}</p>
//         <p><strong>Vehicle Model:</strong> {formData.vehicleModel}</p>
//         <p><strong>Registration Number:</strong> {formData.registrationNumber}</p>
//         <p><strong>Start Date:</strong> {formData.startDate}</p>
//         <p><strong>End Date:</strong> {formData.endDate}</p>
//       </div>
//       <button onClick={handleSubmit} disabled={submitting}>
//         {submitting ? 'Submitting...' : 'Submit'}
//       </button>
//     </div>
//   );
// };
// export default FormStep4;
// import { useState } from 'react';
// const FormStep4 = ({ formData, onSubmit }) => {
//   const [submitting, setSubmitting] = useState(false);
//   const handleSubmit = async () => {
//     console.log('Form Data before submission:', formData); // Debug log
//     setSubmitting(true);
//     try {
//       console.log('Form Data before submission:', formData);
//       const response = await fetch('/api/submitForm', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(formData),
//       });
//       if (!response.ok) {
//         throw new Error('Submission failed');
//       }
//       alert('Form submitted successfully!');
//       onSubmit(); // Reset or navigate away
//     } catch (err) {
//       console.error('Error submitting form:', err);
//       alert('Failed to submit the form. Please try again.');
//     } finally {
//       setSubmitting(false);
//     }
//   };
//   return (
//     <div>
//       <h2>Step 4: Confirm and Submit</h2>
//       <div>
//         <h3>Review your details:</h3>
//         <p><strong>First Name:</strong> {formData.firstName}</p>
//         <p><strong>Last Name:</strong> {formData.lastName}</p>
//         <p><strong>Vehicle Type:</strong> {formData.vehicleType}</p>
//         <p><strong>Vehicle Model:</strong> {formData.vehicleModel}</p>
//         <p><strong>Registration Number:</strong> {formData.registrationNumber}</p>
//         <p><strong>Start Date:</strong> {formData.startDate}</p>
//         <p><strong>End Date:</strong> {formData.endDate}</p>
//       </div>
//       <button onClick={handleSubmit} disabled={submitting}>
//         {submitting ? 'Submitting...' : 'Submit'}
//       </button>
//     </div>
//   );
// };
// export default FormStep4;
// import { useState, useEffect } from 'react';
// const FormStep4 = ({ formData, onSubmit }) => {
//   const [submitting, setSubmitting] = useState(false);
//   // Automatically set the startDate and endDate to today's date
//   useEffect(() => {
//     formData.startDate = formData.startDate || new Date().toISOString().split('T')[0];
//     formData.endDate = formData.endDate || new Date().toISOString().split('T')[0];
//   }, [formData]);
//   const handleSubmit = async () => {
//     setSubmitting(true);
//     try {
//       console.log('Form Data before submission:', formData); 
//       const response = await fetch('/api/submitForm', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(formData),
//       });
//       if (!response.ok) {
//         throw new Error('Submission failed');
//       }
//       alert('Form submitted successfully!');
//       onSubmit(); // Reset or navigate away
//     } catch (err) {
//       console.error('Error submitting form:', err);
//       alert('Failed to submit the form. Please try again.');
//     } finally {
//       setSubmitting(false);
//     }
//   };
//   return (
//     <div>
//       <h2>Step 4: Confirm and Submit</h2>
//       <div>
//         <h3>Review your details:</h3>
//         <p><strong>First Name:</strong> {formData.firstName}</p>
//         <p><strong>Last Name:</strong> {formData.lastName}</p>
//         <p><strong>Vehicle Type:</strong> {formData.vehicleType}</p>
//         <p><strong>Vehicle Model:</strong> {formData.vehicleModel}</p>
//         <p><strong>Registration Number:</strong> {formData.registrationNumber}</p>
//         <p><strong>Start Date:</strong> {formData.startDate}</p>
//         <p><strong>End Date:</strong> {formData.endDate}</p>
//       </div>
//       <button onClick={handleSubmit} disabled={submitting}>
//         {submitting ? 'Submitting...' : 'Submit'}
//       </button>
//     </div>
//   );
// };
// export default FormStep4;
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
const FormStep4 = ({ formData, onSubmit })=>{
    _s();
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Automatically set the startDate and endDate to today's date
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FormStep4.useEffect": ()=>{
            formData.startDate = formData.startDate || new Date().toISOString().split('T')[0];
            formData.endDate = formData.endDate || new Date().toISOString().split('T')[0];
        }
    }["FormStep4.useEffect"], [
        formData
    ]);
    const handleSubmit = async ()=>{
        setSubmitting(true);
        try {
            console.log('Form Data before submission:', formData);
            const response = await fetch('/api/submitForm', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            if (!response.ok) {
                throw new Error('Submission failed');
            }
            alert('Form submitted successfully!');
            onSubmit(); // Reset or navigate away
        } catch (err) {
            console.error('Error submitting form:', err);
            alert('Failed to submit the form. Please try again.');
        } finally{
            setSubmitting(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                children: "Step 4: Confirm and Submit"
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep4.js",
                lineNumber: 194,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        children: "Review your details:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 196,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "First Name:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep4.js",
                                lineNumber: 197,
                                columnNumber: 12
                            }, this),
                            " ",
                            formData.firstName
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 197,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Last Name:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep4.js",
                                lineNumber: 198,
                                columnNumber: 12
                            }, this),
                            " ",
                            formData.lastName
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Vehicle Type:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep4.js",
                                lineNumber: 199,
                                columnNumber: 12
                            }, this),
                            " ",
                            formData.vehicleType
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 199,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Vehicle Model:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep4.js",
                                lineNumber: 200,
                                columnNumber: 12
                            }, this),
                            " ",
                            formData.vehicleModel
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 200,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Registration Number:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep4.js",
                                lineNumber: 201,
                                columnNumber: 12
                            }, this),
                            " ",
                            formData.registrationNumber
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Start Date:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep4.js",
                                lineNumber: 202,
                                columnNumber: 12
                            }, this),
                            " ",
                            formData.startDate
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 202,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "End Date:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/FormStep4.js",
                                lineNumber: 203,
                                columnNumber: 12
                            }, this),
                            " ",
                            formData.endDate
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/FormStep4.js",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/FormStep4.js",
                lineNumber: 195,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleSubmit,
                disabled: submitting,
                children: submitting ? 'Submitting...' : 'Submit'
            }, void 0, false, {
                fileName: "[project]/src/components/FormStep4.js",
                lineNumber: 205,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/FormStep4.js",
        lineNumber: 193,
        columnNumber: 5
    }, this);
};
_s(FormStep4, "isa3J6MfgBZyBRgdh+0Vw6HuRlI=");
_c = FormStep4;
const __TURBOPACK__default__export__ = FormStep4;
var _c;
__turbopack_refresh__.register(_c, "FormStep4");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// import Image from "next/image";
// import styles from "./page.module.css";
// export default function Home() {
//   return (
//     <div className={styles.page}>
//       <main className={styles.main}>
//         <Image
//           className={styles.logo}
//           src="/next.svg"
//           alt="Next.js logo"
//           width={180}
//           height={38}
//           priority
//         />
//         <ol>
//           <li>
//             Get started by editing <code>src/app/page.js</code>.
//           </li>
//           <li>Save and see your changes instantly.</li>
//         </ol>
//         <div className={styles.ctas}>
//           <a
//             className={styles.primary}
//             href="https://vercel.com/new?utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
//             target="_blank"
//             rel="noopener noreferrer"
//           >
//             <Image
//               className={styles.logo}
//               src="/vercel.svg"
//               alt="Vercel logomark"
//               width={20}
//               height={20}
//             />
//             Deploy now
//           </a>
//           <a
//             href="https://nextjs.org/docs?utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
//             target="_blank"
//             rel="noopener noreferrer"
//             className={styles.secondary}
//           >
//             Read our docs
//           </a>
//         </div>
//       </main>
//       <footer className={styles.footer}>
//         <a
//           href="https://nextjs.org/learn?utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           <Image
//             aria-hidden
//             src="/file.svg"
//             alt="File icon"
//             width={16}
//             height={16}
//           />
//           Learn
//         </a>
//         <a
//           href="https://vercel.com/templates?framework=next.js&utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           <Image
//             aria-hidden
//             src="/window.svg"
//             alt="Window icon"
//             width={16}
//             height={16}
//           />
//           Examples
//         </a>
//         <a
//           href="https://nextjs.org?utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           <Image
//             aria-hidden
//             src="/globe.svg"
//             alt="Globe icon"
//             width={16}
//             height={16}
//           />
//           Go to nextjs.org →
//         </a>
//       </footer>
//     </div>
//   );
// }
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import { useState } from 'react';
// import FormStep1 from '@/components/FormStep';
// import FormStep2 from '@/components/FormStep2';
// export default function Home() {
//   const [step, setStep] = useState(1);
//   const [formData, setFormData] = useState({});
//   const handleNext = (data) => {
//     setFormData((prev) => ({ ...prev, ...data }));
//     setStep((prevStep) => prevStep + 1);
//   };
//   return (
//     <div className="container">
//       <h1>Vehicle Booking</h1>
//       {step === 1 && <FormStep1 onNext={handleNext} />}
//       {step === 2 && <FormStep2 onNext={handleNext} />}
//       {step === 3 && <FormStep3 onNext={handleNext} />}
//       {step === 4 && <FormStep4 onNext={handleNext} />}
//       {/* Add more steps here as needed */}
//     </div>
//   );
// }
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/FormStep.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/FormStep2.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/FormStep3.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/FormStep4.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
'use client';
;
;
;
;
;
const App = ()=>{
    _s();
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const handleNext = (data)=>{
        setFormData((prev)=>({
                ...prev,
                ...data
            }));
        setStep((prev)=>prev + 1);
    };
    const handleSubmit = ()=>{
        setFormData({});
        setStep(1); // Reset to step 1 or navigate to another page
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            step === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onNext: handleNext
            }, void 0, false, {
                fileName: "[project]/src/app/page.js",
                lineNumber: 147,
                columnNumber: 22
            }, this),
            step === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onNext: handleNext
            }, void 0, false, {
                fileName: "[project]/src/app/page.js",
                lineNumber: 148,
                columnNumber: 22
            }, this),
            step === 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onNext: handleNext
            }, void 0, false, {
                fileName: "[project]/src/app/page.js",
                lineNumber: 149,
                columnNumber: 22
            }, this),
            step === 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$FormStep4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                formData: formData,
                onSubmit: handleSubmit
            }, void 0, false, {
                fileName: "[project]/src/app/page.js",
                lineNumber: 150,
                columnNumber: 22
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.js",
        lineNumber: 146,
        columnNumber: 5
    }, this);
};
_s(App, "/23UHojXdTfoMXOhOjj7eW27pAo=");
_c = App;
const __TURBOPACK__default__export__ = App;
var _c;
__turbopack_refresh__.register(_c, "App");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.js [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_d57bbc._.js.map