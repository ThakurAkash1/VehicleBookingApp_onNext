__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_f1b02b._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_beb007._.js",
  "static/chunks/[root of the server]__951f35._.js",
  "static/chunks/src_pages__app_5771e1._.js",
  "static/chunks/src_pages__app_2aa630._.js"
])
