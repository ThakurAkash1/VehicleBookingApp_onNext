module.exports = {

"[externals]/next/dist/compiled/next-server/pages-api.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/next-server/pages-api.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/sequelize [external] (sequelize, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("sequelize", () => require("sequelize"));

module.exports = mod;
}}),
"[project]/src/utils/db.js [api] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
// const { Sequelize } = require('sequelize');
// // Establishing a connection to SQL Server using Sequelize
// const sequelize = new Sequelize('VehicleBooking', 'root', 'Akash@123', {
//   host: 'localhost', // Database host, usually localhost for local setups
//   dialect: 'mssql',  // SQL Server dialect for Sequelize
//   dialectOptions: {
//     // Any options specific to SQL Server (e.g., trustServerCertificate for local development)
//     trustServerCertificate: true, // Set to true if using self-signed certificates in local dev
//   },
//   logging: false, // Disable logging of SQL queries, can be true for debugging
// });
// module.exports = sequelize;
// const { Sequelize } = require('sequelize');
// let sequelize;
// if (process.env.NODE_ENV === 'development') {
//   // In development, don't create a new connection every time
//   if (!global.sequelize) {
//     global.sequelize = new Sequelize('VehicleBooking', 'root', 'Akash@123', {
//       host: 'localhost',
//       dialect: 'mysql',
//       port: 3306,
//       logging: false,
//     });
//   }
//   sequelize = global.sequelize;
// } else {
//   // In production, always create a new connection
//   sequelize = new Sequelize('VehicleBooking', 'root', 'Akash@123', {
//     host: 'localhost',
//     dialect: 'mysql',
//     port: 3306,
//     logging: false,
//   });
// }
// module.exports = sequelize;
// const { Sequelize, DataTypes } = require('sequelize');
// // Initialize Sequelize instance
// const sequelize = new Sequelize('VehicleBooking', 'root', 'Akash@123', {
//   host: 'localhost',
//   dialect: 'mysql',
//   port: 3306,
// });
// const VehicleType = sequelize.define('VehicleType', {
//   id: {
//     type: DataTypes.INTEGER,
//     primaryKey: true,
//     autoIncrement: true,
//   },
//   type: {  // Assuming 'type' is the correct field based on your database
//     type: DataTypes.STRING,
//     allowNull: false,
//   },
// });
// module.exports = VehicleType;
const { Sequelize } = __turbopack_require__("[externals]/sequelize [external] (sequelize, cjs)");
// Initialize Sequelize instance
const sequelize = new Sequelize('VehicleBooking', 'root', 'Akash@123', {
    host: 'localhost',
    dialect: 'mysql',
    port: 3306
});
// Test database connection
sequelize.authenticate().then(()=>{
    console.log('Database connection established successfully.');
    // Synchronize models with the database
    return sequelize.sync({
        force: false
    }); // Change to `true` to reset tables in development
}).then(()=>{
    console.log('Database synchronized successfully.');
}).catch((error)=>{
    console.error('Error connecting to or synchronizing the database:', error);
});
module.exports = sequelize;
}}),
"[project]/src/models/Vehicle.js [api] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
// const { DataTypes } = require('sequelize');
// const sequelize = require('../utils/db');
// const VehicleType = require('./VehicleType');
// const Vehicle = sequelize.define('Vehicle', {
//     id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
//     name: { type: DataTypes.STRING, allowNull: false },
//     typeId: { type: DataTypes.INTEGER, references: { model: VehicleType, key: 'id' } },
// });
// module.exports = Vehicle;
// import { DataTypes } from 'sequelize';
// import sequelize from '../utils/db';
// import VehicleType from './VehicleType';
// const Vehicle = sequelize.define('Vehicle', {
//     id: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true,
//     },
//     name: {
//         type: DataTypes.STRING,
//         allowNull: false,
//     },
//     vehicleTypeId: {
//         type: DataTypes.INTEGER,
//         references: {
//             model: VehicleType,
//             key: 'id',
//         },
//     },
// });
// Vehicle.belongsTo(VehicleType, { foreignKey: 'vehicleTypeId' });
// export default Vehicle;
const { DataTypes } = __turbopack_require__("[externals]/sequelize [external] (sequelize, cjs)");
const sequelize = __turbopack_require__("[project]/src/utils/db.js [api] (ecmascript)");
const Vehicle = sequelize.define('Vehicle', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    typeId: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
});
module.exports = Vehicle;
}}),
"[project]/src/models/Booking.js [api] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const { DataTypes } = __turbopack_require__("[externals]/sequelize [external] (sequelize, cjs)");
const sequelize = __turbopack_require__("[project]/src/utils/db.js [api] (ecmascript)");
const Vehicle = __turbopack_require__("[project]/src/models/Vehicle.js [api] (ecmascript)");
const Booking = sequelize.define('Booking', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    vehicleId: {
        type: DataTypes.INTEGER,
        references: {
            model: Vehicle,
            key: 'id'
        }
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    startDate: {
        type: DataTypes.DATE,
        allowNull: false
    },
    endDate: {
        type: DataTypes.DATE,
        allowNull: false
    }
});
module.exports = Booking;
}}),
"[project]/src/pages/api/submitForm.js [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// export default async function handler(req, res) {
//     if (req.method === 'POST') {
//       try {
//         const formData = req.body;
//         console.log('Form submitted:', formData);
//         // Save to database or process the data here
//         res.status(200).json({ message: 'Form submitted successfully' });
//       } catch (error) {
//         console.error('Error submitting form:', error);
//         res.status(500).json({ error: 'Failed to submit form' });
//       }
//     } else {
//       res.status(405).json({ message: 'Method Not Allowed' });
//     }
//   }
// import sequelize from '@/utils/db';
// import VehicleType from '../../models/VehicleType'; // Import your Sequelize models
// import Vehicle from '../../models/Vehicle';
// import Booking from '../../models/Booking';
// export default async function handler(req, res) {
//   if (req.method === 'POST') {
//     try {
//       const { firstName, lastName, vehicleType, vehicleModel, registrationNumber, startDate, endDate } = req.body;
//       // Find or create the vehicle type
//       let vehicleTypeRecord = await VehicleType.findOne({ where: { type: vehicleType } });
//       if (!vehicleTypeRecord) {
//         vehicleTypeRecord = await VehicleType.create({ type: vehicleType });
//       }
//       // Find or create the vehicle
//       let vehicle = await Vehicle.findOne({ where: { name: vehicleModel, typeId: vehicleTypeRecord.id } });
//       if (!vehicle) {
//         vehicle = await Vehicle.create({ name: vehicleModel, typeId: vehicleTypeRecord.id });
//       }
//       // Create the booking
//       await Booking.create({
//         vehicleId: vehicle.id,
//         name: `${firstName} ${lastName}`,
//         firstName,
//         lastName,
//         startDate,
//         endDate,
//       });
//       res.status(200).json({ message: 'Booking successful' });
//     } catch (error) {
//       console.error('Error submitting booking:', error);
//       res.status(500).json({ error: 'Failed to save booking data' });
//     }
//   } else {
//     res.status(405).json({ message: 'Method Not Allowed' });
//   }
// }
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Booking$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/models/Booking.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Vehicle$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/models/Vehicle.js [api] (ecmascript)");
;
;
// const Vehicle = require('../models/Vehicle');
// const Booking = require('../models/Booking');
const handler = async (req, res)=>{
    if (req.method === 'POST') {
        try {
            const { firstName, lastName, vehicleType, vehicleModel, startDate, endDate } = req.body;
            // Find vehicle type
            const vehicleTypeRecord = await VehicleType.findOne({
                where: {
                    type: vehicleType
                }
            });
            if (!vehicleTypeRecord) {
                return res.status(404).json({
                    error: 'Vehicle type not found'
                });
            }
            // Find or create the vehicle
            let vehicle = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Vehicle$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].findOne({
                where: {
                    name: vehicleModel,
                    typeId: vehicleTypeRecord.id
                }
            });
            if (!vehicle) {
                vehicle = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Vehicle$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].create({
                    name: vehicleModel,
                    typeId: vehicleTypeRecord.id
                });
            }
            // Create booking
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Booking$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].create({
                vehicleId: vehicle.id,
                name: `${firstName} ${lastName}`,
                startDate,
                endDate,
                firstName,
                lastName
            });
            res.status(201).json({
                message: 'Booking successful'
            });
        } catch (error) {
            console.error('Error submitting booking:', error);
            res.status(500).json({
                error: 'Failed to submit booking'
            });
        }
    } else {
        res.status(405).json({
            error: 'Method not allowed'
        });
    }
};
const __TURBOPACK__default__export__ = handler;
}}),
"[project]/node_modules/next/dist/esm/server/route-modules/pages-api/module.compiled.js [api] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
} else {
    if ("TURBOPACK compile-time truthy", 1) {
        module.exports = __turbopack_require__("[externals]/next/dist/compiled/next-server/pages-api.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api.runtime.dev.js, cjs)");
    } else {
        "TURBOPACK unreachable";
    }
} //# sourceMappingURL=module.compiled.js.map
}}),
"[project]/node_modules/next/dist/esm/server/route-kind.js [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RouteKind": (()=>RouteKind)
});
var RouteKind = /*#__PURE__*/ function(RouteKind) {
    /**
   * `PAGES` represents all the React pages that are under `pages/`.
   */ RouteKind["PAGES"] = "PAGES";
    /**
   * `PAGES_API` represents all the API routes under `pages/api/`.
   */ RouteKind["PAGES_API"] = "PAGES_API";
    /**
   * `APP_PAGE` represents all the React pages that are under `app/` with the
   * filename of `page.{j,t}s{,x}`.
   */ RouteKind["APP_PAGE"] = "APP_PAGE";
    /**
   * `APP_ROUTE` represents all the API routes and metadata routes that are under `app/` with the
   * filename of `route.{j,t}s{,x}`.
   */ RouteKind["APP_ROUTE"] = "APP_ROUTE";
    /**
   * `IMAGE` represents all the images that are generated by `next/image`.
   */ RouteKind["IMAGE"] = "IMAGE";
    return RouteKind;
}({}); //# sourceMappingURL=route-kind.js.map
}}),
"[project]/node_modules/next/dist/esm/build/templates/helpers.js [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/**
 * Hoists a name from a module or promised module.
 *
 * @param module the module to hoist the name from
 * @param name the name to hoist
 * @returns the value on the module (or promised module)
 */ __turbopack_esm__({
    "hoist": (()=>hoist)
});
function hoist(module, name) {
    // If the name is available in the module, return it.
    if (name in module) {
        return module[name];
    }
    // If a property called `then` exists, assume it's a promise and
    // return a promise that resolves to the name.
    if ('then' in module && typeof module.then === 'function') {
        return module.then((mod)=>hoist(mod, name));
    }
    // If we're trying to hoise the default export, and the module is a function,
    // return the module itself.
    if (typeof module === 'function' && name === 'default') {
        return module;
    }
    // Otherwise, return undefined.
    return undefined;
} //# sourceMappingURL=helpers.js.map
}}),
"[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/submitForm.js [api] (ecmascript)\" } [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "config": (()=>config),
    "default": (()=>__TURBOPACK__default__export__),
    "routeModule": (()=>routeModule)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$modules$2f$pages$2d$api$2f$module$2e$compiled$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/esm/server/route-modules/pages-api/module.compiled.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$kind$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/esm/server/route-kind.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$build$2f$templates$2f$helpers$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/esm/build/templates/helpers.js [api] (ecmascript)");
// Import the userland code.
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$submitForm$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/pages/api/submitForm.js [api] (ecmascript)");
;
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$build$2f$templates$2f$helpers$2e$js__$5b$api$5d$__$28$ecmascript$29$__["hoist"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$submitForm$2e$js__$5b$api$5d$__$28$ecmascript$29$__, 'default');
const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$build$2f$templates$2f$helpers$2e$js__$5b$api$5d$__$28$ecmascript$29$__["hoist"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$submitForm$2e$js__$5b$api$5d$__$28$ecmascript$29$__, 'config');
const routeModule = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$modules$2f$pages$2d$api$2f$module$2e$compiled$2e$js__$5b$api$5d$__$28$ecmascript$29$__["PagesAPIRouteModule"]({
    definition: {
        kind: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$route$2d$kind$2e$js__$5b$api$5d$__$28$ecmascript$29$__["RouteKind"].PAGES_API,
        page: "/api/submitForm",
        pathname: "/api/submitForm",
        // The following aren't used in production.
        bundlePath: '',
        filename: ''
    },
    userland: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$api$2f$submitForm$2e$js__$5b$api$5d$__$28$ecmascript$29$__
}); //# sourceMappingURL=pages-api.js.map
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__0b1477._.js.map